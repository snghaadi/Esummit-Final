<?php
    $connection = mysqli_connect('localhost','u862867315_root_9','Utkarsh@3112','u862867315_esummit_22');
