<?php
    $connection = mysqli_connect('localhost','root','','esummit_22');
?>